//
//  LoginViewController.swift
//  Flash Chat iOS13
//
//  Created by rafi menashe on 26/12/2020.

//

import UIKit
import Firebase
class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    let email = "rafi@gmail.com"
    let password = "R1234567"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTextfield.text    = email
        passwordTextfield.text = password
        
    }

    @IBAction func loginPressed(_ sender: UIButton) {
        
        guard let email = emailTextfield.text , let password = passwordTextfield.text else {
            emailTextfield.text = "enter email and password"; return
        }
        // MARK: - Section Heading
        Auth.auth().signIn(withEmail: email, password: password) { [weak self] authResult, error in
            
            if let error = error{
                
                self?.emailTextfield.text = error.localizedDescription
                
            }else{
                self?.performSegue(withIdentifier: K.loginSegue, sender: self)
                // ...
            }
        }}
    
}
