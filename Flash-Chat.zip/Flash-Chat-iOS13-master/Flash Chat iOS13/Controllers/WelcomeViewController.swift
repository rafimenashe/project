//
//  WelcomeViewController.swift
//  Flash Chat iOS13
//
//  Created by rafi menashe on 26/12/2020.
//

import UIKit


class WelcomeViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        animationWithCode()
    }

    // MARK: - Section Heading animation
    func animationWithCode(){
        titleLabel.text = ""
        let str = K.nameApp
        var time = 0.0
        for char in str{
            Timer.scheduledTimer(withTimeInterval: 0.1 * time, repeats: false) { (timer) in
                self.titleLabel.text?.append(char)
            }
            time += 1
        }
        
    }
}
