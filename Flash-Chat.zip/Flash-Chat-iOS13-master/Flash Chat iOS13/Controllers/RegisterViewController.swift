//
//  RegisterViewController.swift
//  Flash Chat iOS13
//
// Created by rafi menashe on 26/12/2020.
//

import UIKit
import Firebase

class RegisterViewController: UIViewController {

    @IBOutlet weak var emailTextfield: UITextField!
    @IBOutlet weak var passwordTextfield: UITextField!
    
    @IBAction func registerPressed(_ sender: UIButton) {
        // MARK: - Section Heading fireBase create a user
        
        guard let email = emailTextfield.text, let password = passwordTextfield.text,
              email != "" && password != ""
              else {
            emailTextfield.text = "enter email and password"
            return
            
        }
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            if let error = error{
                print(error)
            } else{
                self.performSegue(withIdentifier: K.registerSegue, sender: self)
            }
        }
    }
    
}
