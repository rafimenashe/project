//
//  File.swift
//  Flash Chat iOS13
//
//  Created by rafi menashe on 26/12/2020.
//

import Foundation


struct Message {
    let sender:String
    let body  :String
}
